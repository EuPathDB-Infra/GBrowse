#!/usr/bin/perl -w
use strict;

# unlink 'GGB.def';
#unlink 'cgi-bin/das';
#unlink 'cgi-bin/gbrowse';
#unlink 'cgi-bin/gbrowse_img';
#unlink 'cgi-bin/gbrowse_details';
#unlink 'cgi-bin/gbrowse_est';
#unlink 'cgi-bin/gbrowse_moby';
#unlink 'cgi-bin/moby_server';
unlink 'install_util/cgi_install.pl';
unlink 'install_util/conf_install.pl';
unlink 'install_util/gbrowse_ppm_install.pl';
unlink 'install_util/htdocs_install.pl';
unlink 'gbrowse_ppm_install.pl';
unlink 'gbrowse_ppm_support_files-1.63.tar.gz';
unlink 'gbrowse_ppm-1.63.tar.gz';
unlink 'Generic-Genome-Browser.ppd';
